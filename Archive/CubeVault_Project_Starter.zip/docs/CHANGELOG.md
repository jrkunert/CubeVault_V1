# Changelog

## [Unreleased]
### Added
- Initial architecture
- Development standards
- Foundation sprint definition
