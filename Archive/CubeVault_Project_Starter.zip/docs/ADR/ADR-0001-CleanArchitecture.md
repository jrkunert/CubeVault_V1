# ADR-0001

Status: Accepted

Decision:
Use Clean Architecture with dependency inversion, repositories, services, and provider isolation.

Consequences:
- Easier testing
- Better maintainability
- Provider independence
