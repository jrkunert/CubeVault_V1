# CubeVault Project Manifest

## Mission
Build a commercial-grade OneStream Data Lifecycle Management platform.

## Permanent Assumptions
1. Write complete sections/layers of code rather than individual commits.
2. Minor architectural improvements are pre-approved. Implement them and summarize changes.
3. Provide downloadable source files whenever a logical section is complete.
4. Keep the solution buildable after every deliverable.
5. Generate production-ready code only.
6. Update documentation automatically.

## Architecture
- Clean Architecture
- SOLID
- Repository Pattern
- Service Layer
- Dependency Injection
- Pipeline Architecture
- Stored Procedures Only
- Thin Business Rules

## Current Phase
Sprint 0 – Foundation (Common + Persistence).
