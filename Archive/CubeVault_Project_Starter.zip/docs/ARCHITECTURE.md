# Architecture

Projects
- CubeVault.Common
- CubeVault.Domain
- CubeVault.Application
- CubeVault.Infrastructure
- CubeVault.Persistence.SqlServer
- CubeVault.Provider.OneStream
- CubeVault.BusinessRule
- CubeVault.SDK

Development Order
Database -> Stored Procedure -> Repository -> Service -> Pipeline -> Business Rule -> Tests -> Documentation
